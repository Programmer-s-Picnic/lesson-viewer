import { createInitialBoardState, createStore, TOOLS, deepClone } from "./state.js";
import { createRect, createEllipse, createDiamond, createLine, createArrow, createText, createGroup } from "./factories.js";
import { COMMANDS, createHistory, createCommandManager } from "./commands.js";
import { normalizeRect, hitTest, getSelectionObjects, getSelectionBounds, getObjectById, getObjectBounds, marqueeIntersect, getTopSelectableId } from "./selection.js";
import { createRenderer } from "./renderer.js";

const canvas = document.getElementById("board");
const store = createStore(createInitialBoardState());
const history = createHistory();
const commandManager = createCommandManager(store, history);
const renderer = createRenderer(canvas, store);

const statusText = document.getElementById("statusText");
const strokeColorInput = document.getElementById("strokeColor");
const fillColorInput = document.getElementById("fillColor");
const strokeWidthInput = document.getElementById("strokeWidth");
const strokeWidthValue = document.getElementById("strokeWidthValue");
const fontFamilyInput = document.getElementById("fontFamily");
const fontSizeInput = document.getElementById("fontSize");
const fontSizeValue = document.getElementById("fontSizeValue");
const propStroke = document.getElementById("propStroke");
const propFill = document.getElementById("propFill");
const propWidth = document.getElementById("propWidth");
const propHeight = document.getElementById("propHeight");
const propStrokeWidth = document.getElementById("propStrokeWidth");
const propFontFamily = document.getElementById("propFontFamily");
const propFontSize = document.getElementById("propFontSize");
const propText = document.getElementById("propText");
const shareHashBtn = document.getElementById("shareHashBtn");
const shareQueryBtn = document.getElementById("shareQueryBtn");
const helpToggle = document.getElementById("helpToggle");
const helpPanel = document.getElementById("helpPanel");
const quickBoxInput = document.getElementById("quickBoxInput");
const quickBoxBtn = document.getElementById("quickBoxBtn");
const quickBoxClearBtn = document.getElementById("quickBoxClearBtn");
const quickBannerInput = document.getElementById("quickBannerInput");
const quickBannerBtn = document.getElementById("quickBannerBtn");
const quickBannerClearBtn = document.getElementById("quickBannerClearBtn");
const movementTraceBtn = document.getElementById("movementTraceBtn");
const editTextInput = document.getElementById("editTextInput");
const editSelectedTextBtn = document.getElementById("editSelectedTextBtn");
const editTextNote = document.getElementById("editTextNote");

const interaction = {
  pointerDown: false,
  dragMode: null, // create | marquee | move
  startWorld: null,
  startScreen: null,
  activeDraftObject: null,
  moveSnapshot: null,
  eraseIds: new Set(),
};

const movementTrace = {
  enabled: false,
};

function updateStatus() {
  const state = store.getState();
  statusText.textContent = `${state.objects.length} items · ${state.selection.selectedIds.length} selected`;
}

store.subscribe(() => {
  renderer.requestRender();
  updateStatus();
  syncPropertyPanel();
  syncSelectedTextEditor();
  syncColorInputs();
});

function getPointerScreenPosition(event) {
  const r = canvas.getBoundingClientRect();
  return { x: event.clientX - r.left, y: event.clientY - r.top };
}

function updateCanvasCursor(tool) {
  const cursorMap = {
    select: "default",
    rect: "crosshair",
    ellipse: "crosshair",
    diamond: "crosshair",
    line: "cell",
    arrow: "cell",
    text: "text",
    eraser: "not-allowed",
  };
  canvas.style.cursor = cursorMap[tool] || "crosshair";
}

function syncColorInputs() {
  const state = store.getState();
  if (strokeColorInput) strokeColorInput.value = state.toolState.toolOptions.stroke || "#1f2328";
  if (fillColorInput) fillColorInput.value = state.toolState.toolOptions.fill || "#fff1c7";
  if (strokeWidthInput) strokeWidthInput.value = state.toolState.toolOptions.strokeWidth || 2;
  if (strokeWidthValue) strokeWidthValue.textContent = String(state.toolState.toolOptions.strokeWidth || 2);
  if (fontFamilyInput) fontFamilyInput.value = state.toolState.toolOptions.fontFamily || "Inter, sans-serif";
  if (fontSizeInput) fontSizeInput.value = state.toolState.toolOptions.fontSize || 18;
  if (fontSizeValue) fontSizeValue.textContent = String(state.toolState.toolOptions.fontSize || 18);
}

function getPrimarySelectedObject() {
  const state = store.getState();
  const selection = getSelectionObjects(state);
  return selection.length ? selection[0] : null;
}

function syncPropertyPanel() {
  const obj = getPrimarySelectedObject();
  const disabled = !obj;

  [propStroke, propFill, propWidth, propHeight, propStrokeWidth, propFontFamily, propFontSize, propText].forEach((el) => {
    if (el) el.disabled = disabled;
  });

  if (!obj) {
    if (propText) propText.value = "";
    if (propWidth) propWidth.value = "";
    if (propHeight) propHeight.value = "";
    if (propFontFamily) propFontFamily.value = "Inter, sans-serif";
    if (propFontSize) propFontSize.value = 18;
    return;
  }

  const stroke = obj.style?.stroke || obj.style?.color || "#1f2328";
  const fill = obj.style?.fill || "#fff1c7";
  const sw = obj.style?.strokeWidth || 2;

  if (propStroke) propStroke.value = normalizeColor(stroke);
  if (propFill) propFill.value = normalizeColor(fill);
  if (propStrokeWidth) propStrokeWidth.value = sw;
  if (propWidth) propWidth.value = obj.width ?? "";
  if (propHeight) propHeight.value = obj.height ?? "";
  if (propFontFamily) propFontFamily.value = obj.style?.fontFamily || "Inter, sans-serif";
  if (propFontSize) propFontSize.value = obj.style?.fontSize || 18;
  if (propText) propText.value = obj.text || "";
}

function normalizeColor(value) {
  if (!value) return "#1f2328";
  if (value.startsWith("#") && (value.length === 7 || value.length === 4)) return value;
  return "#1f2328";
}

function updateSelectedObjects(mutator) {
  const state = store.getState();
  const selection = getSelectionObjects(state);
  if (!selection.length) return;

  const ids = new Set(selection.map((o) => o.id));
  const before = selection.map((o) => deepClone(o));
  const nextObjects = state.objects.map((obj) => {
    if (!ids.has(obj.id)) return obj;
    const copy = deepClone(obj);
    mutator(copy);
    return copy;
  });
  const after = nextObjects.filter((o) => ids.has(o.id)).map((o) => deepClone(o));

  commandManager.execute({
    type: COMMANDS.UPDATE_OBJECTS,
    payload: { before, after },
  });
}


function getEditableSelectedObjects() {
  return getSelectionObjects(store.getState()).filter((obj) => (
    obj &&
    obj.type !== "line" &&
    obj.type !== "arrow" &&
    Object.prototype.hasOwnProperty.call(obj, "text")
  ));
}

function resizeObjectForText(obj, value) {
  const copy = deepClone(obj);
  copy.text = value;
  copy.style = copy.style || {};
  const fontSize = Number(copy.style.fontSize) || 20;
  const minWidth = value.length * (fontSize * 0.72) + 42;
  if (typeof copy.width === "number") copy.width = Math.max(copy.width, Math.min(760, minWidth));
  return copy;
}

function syncSelectedTextEditor() {
  if (!editTextInput && !editTextNote && !editSelectedTextBtn) return;

  const editable = getEditableSelectedObjects();

  if (!editable.length) {
    if (editTextInput) {
      editTextInput.value = "";
      editTextInput.disabled = true;
      editTextInput.placeholder = "Select a box or banner first";
    }
    if (editSelectedTextBtn) editSelectedTextBtn.disabled = true;
    if (editTextNote) editTextNote.textContent = "Select a box or banner to change its text.";
    return;
  }

  if (editTextInput) {
    editTextInput.disabled = false;
    editTextInput.placeholder = "Type new text";
    const texts = [...new Set(editable.map((obj) => String(obj.text || "")))];
    editTextInput.value = texts.length === 1 ? texts[0] : "";
  }

  if (editSelectedTextBtn) editSelectedTextBtn.disabled = false;

  if (editTextNote) {
    editTextNote.textContent = editable.length === 1
      ? "Editing 1 selected item."
      : `Editing ${editable.length} selected items. The same text will be applied to all.`;
  }
}

function updateSelectedTextFromEditor() {
  if (!editTextInput) return;
  const value = editTextInput.value.trim();
  if (!value) {
    alert("Type the new text first.");
    editTextInput.focus();
    return;
  }

  const editable = getEditableSelectedObjects();
  if (!editable.length) {
    alert("Select a box or banner first.");
    return;
  }

  const before = editable.map((obj) => deepClone(obj));
  const after = editable.map((obj) => resizeObjectForText(obj, value));

  commandManager.execute({
    type: COMMANDS.UPDATE_OBJECTS,
    payload: { before, after },
  });

  setActiveTool(TOOLS.SELECT);
}

let inlineTextEditor = null;

function isEditableTextObject(obj) {
  return Boolean(
    obj &&
    obj.type !== "line" &&
    obj.type !== "arrow" &&
    Object.prototype.hasOwnProperty.call(obj, "text")
  );
}

function worldRectToBoardRect(bounds) {
  const state = store.getState();
  const shellRect = canvas.parentElement.getBoundingClientRect();
  const canvasRect = canvas.getBoundingClientRect();
  const offsetX = canvasRect.left - shellRect.left;
  const offsetY = canvasRect.top - shellRect.top;

  return {
    left: offsetX + bounds.x * state.camera.zoom + state.camera.panX,
    top: offsetY + bounds.y * state.camera.zoom + state.camera.panY,
    width: bounds.width * state.camera.zoom,
    height: bounds.height * state.camera.zoom,
  };
}

function closeInlineTextEditor({ commit = false } = {}) {
  if (!inlineTextEditor) return;

  const { input, objectId } = inlineTextEditor;
  inlineTextEditor = null;

  input.removeEventListener("blur", input.__commitOnBlur);
  input.remove();

  if (!commit) return;

  const value = input.value.trim();
  if (!value) return;

  const state = store.getState();
  const obj = getObjectById(state, objectId);
  if (!isEditableTextObject(obj)) return;
  if (String(obj.text || "") === value) return;

  commandManager.execute({
    type: COMMANDS.UPDATE_OBJECTS,
    payload: {
      before: [deepClone(obj)],
      after: [resizeObjectForText(obj, value)],
    },
  });
}

function beginInlineTextEdit(obj) {
  if (!isEditableTextObject(obj)) return;
  closeInlineTextEditor({ commit: false });

  const bounds = getObjectBounds(obj);
  if (!bounds) return;

  const boardRect = worldRectToBoardRect(bounds);
  const state = store.getState();
  store.setState({
    ...state,
    selection: {
      ...state.selection,
      selectedIds: [obj.id],
    },
  });

  const input = document.createElement("input");
  input.type = "text";
  input.className = "inline-text-editor";
  input.value = String(obj.text || "");
  input.setAttribute("aria-label", "Edit box or banner text");
  input.style.left = `${boardRect.left + 6}px`;
  input.style.top = `${boardRect.top + 6}px`;
  input.style.width = `${Math.max(64, boardRect.width - 12)}px`;
  input.style.height = `${Math.max(36, boardRect.height - 12)}px`;
  input.style.fontSize = `${Math.max(16, (Number(obj.style?.fontSize) || 20) * (store.getState().camera?.zoom || 1))}px`;

  input.addEventListener("pointerdown", (event) => event.stopPropagation());
  input.addEventListener("click", (event) => event.stopPropagation());
  input.addEventListener("dblclick", (event) => event.stopPropagation());
  input.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      closeInlineTextEditor({ commit: true });
      canvas.focus?.();
    }
    if (event.key === "Escape") {
      event.preventDefault();
      closeInlineTextEditor({ commit: false });
      canvas.focus?.();
    }
  });

  input.__commitOnBlur = () => closeInlineTextEditor({ commit: true });
  input.addEventListener("blur", input.__commitOnBlur);

  canvas.parentElement.appendChild(input);
  inlineTextEditor = { input, objectId: obj.id };

  requestAnimationFrame(() => {
    input.focus();
    input.select();
  });
}

function editObjectText(obj) {
  beginInlineTextEdit(obj);
}


function parseQuickBoxEntries(text) {
  return String(text || "")
    .split(/[\s,;|]+/)
    .map((item) => item.trim())
    .filter(Boolean)
    .slice(0, 100);
}

function getQuickBoxStartPosition(state) {
  const bounds = state.objects.map(getObjectBounds).filter(Boolean);
  const maxY = bounds.length ? Math.max(...bounds.map((box) => box.y + box.height)) : 40;
  return { x: 90, y: Math.max(90, maxY + 48) };
}

function createQuickBoxObjects(sourceState, entries, startX, startY) {
  const canvasRect = canvas.getBoundingClientRect();
  const zoom = sourceState.camera?.zoom || 1;
  const usableWidth = Math.max(360, (canvasRect.width / zoom) - 360);
  const rowLimit = startX + usableWidth;
  const gap = 14;
  const rowGap = 18;
  const height = 52;
  const objects = [];
  let cursorX = startX;
  let cursorY = startY;
  let tempState = { ...sourceState, objects: [...sourceState.objects] };

  for (const entry of entries) {
    const width = Math.max(76, Math.min(210, entry.length * 15 + 48));
    if (cursorX > startX && cursorX + width > rowLimit) {
      cursorX = startX;
      cursorY += height + rowGap;
    }

    // One object only: the value is stored inside the box.
    // This means selecting, moving, deleting, saving, and loading treats
    // the box and its number as a single beginner-friendly item.
    const rect = createRect(tempState, cursorX, cursorY, width, height);
    rect.radius = 10;
    rect.text = entry;
    rect.textAlign = "center";
    rect.verticalAlign = "middle";
    rect.style = {
      ...rect.style,
      fontSize: Math.min(26, Math.max(20, Number(tempState.toolState?.toolOptions?.fontSize) || 20)),
      fontFamily: tempState.toolState?.toolOptions?.fontFamily || "Inter, sans-serif",
      fontWeight: 800,
      color: tempState.toolState?.toolOptions?.stroke || "#1f2328",
    };

    objects.push(rect);
    tempState.objects.push(rect);
    cursorX += width + gap;
  }

  return objects;
}

function makeQuickBoxes({ clearFirst = false } = {}) {
  const entries = parseQuickBoxEntries(quickBoxInput?.value || "");
  if (!entries.length) {
    alert("Type some values first. Example: 2,3,4,55,6");
    quickBoxInput?.focus();
    return;
  }

  if (entries.length > 60 && !confirm(`This will create ${entries.length} boxes. Continue?`)) return;

  if (clearFirst) {
    const previousState = deepClone(store.getState());
    const freshState = createInitialBoardState();
    const objects = createQuickBoxObjects(freshState, entries, 90, 90);
    commandManager.execute({
      type: COMMANDS.LOAD_BOARD,
      payload: {
        previousState,
        state: {
          ...freshState,
          objects,
          selection: {
            ...freshState.selection,
            selectedIds: objects.map((obj) => obj.id),
          },
        },
      },
    });
  } else {
    const state = store.getState();
    const start = getQuickBoxStartPosition(state);
    const objects = createQuickBoxObjects(state, entries, start.x, start.y);
    commandManager.execute({
      type: COMMANDS.ADD_OBJECTS,
      payload: { objects },
    });
    const next = store.getState();
    store.setState({
      ...next,
      selection: {
        ...next.selection,
        selectedIds: objects.map((obj) => obj.id),
      },
    });
  }

  setActiveTool(TOOLS.SELECT);
  renderer.requestRender();
}


function getBannerStartPosition(state) {
  const bounds = state.objects.map(getObjectBounds).filter(Boolean);
  const maxY = bounds.length ? Math.max(...bounds.map((box) => box.y + box.height)) : 40;
  return { x: 90, y: Math.max(90, maxY + 54) };
}

function createBannerObjects(sourceState, entries, startX, startY) {
  const canvasRect = canvas.getBoundingClientRect();
  const zoom = sourceState.camera?.zoom || 1;
  const maxWidth = Math.max(360, (canvasRect.width / zoom) - 220);
  const width = Math.min(760, maxWidth);
  const height = 64;
  const gap = 16;
  const objects = [];
  let cursorY = startY;
  let tempState = { ...sourceState, objects: [...sourceState.objects] };

  for (const entry of entries) {
    const rect = createRect(tempState, startX, cursorY, width, height);
    rect.radius = 16;
    rect.text = entry;
    rect.textAlign = "center";
    rect.verticalAlign = "middle";
    rect.style = {
      ...rect.style,
      fill: "#fde68a",
      stroke: tempState.toolState?.toolOptions?.stroke || "#1f2328",
      strokeWidth: 3,
      fontSize: 26,
      fontFamily: tempState.toolState?.toolOptions?.fontFamily || "Inter, sans-serif",
      fontWeight: 900,
      color: tempState.toolState?.toolOptions?.stroke || "#1f2328",
    };

    objects.push(rect);
    tempState.objects.push(rect);
    cursorY += height + gap;
  }

  return objects;
}

function makeQuickBanners({ clearFirst = false } = {}) {
  const entries = parseQuickBoxEntries(quickBannerInput?.value || "");
  if (!entries.length) {
    alert("Type some banner headings first. Example: Start, Compare, Swap, Finish");
    quickBannerInput?.focus();
    return;
  }

  if (entries.length > 40 && !confirm(`This will create ${entries.length} banners. Continue?`)) return;

  if (clearFirst) {
    const previousState = deepClone(store.getState());
    const freshState = createInitialBoardState();
    const objects = createBannerObjects(freshState, entries, 90, 90);
    commandManager.execute({
      type: COMMANDS.LOAD_BOARD,
      payload: {
        previousState,
        state: {
          ...freshState,
          objects,
          selection: {
            ...freshState.selection,
            selectedIds: objects.map((obj) => obj.id),
          },
        },
      },
    });
  } else {
    const state = store.getState();
    const start = getBannerStartPosition(state);
    const objects = createBannerObjects(state, entries, start.x, start.y);
    commandManager.execute({
      type: COMMANDS.ADD_OBJECTS,
      payload: { objects },
    });
    const next = store.getState();
    store.setState({
      ...next,
      selection: {
        ...next.selection,
        selectedIds: objects.map((obj) => obj.id),
      },
    });
  }

  setActiveTool(TOOLS.SELECT);
  renderer.requestRender();
}

function addEraseHit(world) {
  const state = store.getState();
  const hit = hitTest(state, world.x, world.y);
  if (!hit) return;
  interaction.eraseIds.add(hit.id);
  store.setState({
    ...state,
    selection: {
      ...state.selection,
      selectedIds: [...interaction.eraseIds],
    },
  });
}

function finalizeErase() {
  if (!interaction.eraseIds || !interaction.eraseIds.size) return;
  const state = store.getState();
  const ids = [...interaction.eraseIds];
  const idSet = new Set(ids);
  const deletedObjects = ids.map((id) => getObjectById(state, id)).filter(Boolean).map(deepClone);
  const affectedGroups = state.groups
    .filter((group) => group.childIds.some((childId) => idSet.has(childId)) || ids.includes(group.id))
    .map(deepClone);

  commandManager.execute({
    type: COMMANDS.DELETE_OBJECTS,
    payload: {
      ids,
      objectsBackup: deletedObjects,
      groupsBackup: affectedGroups,
    },
  });
}

function setActiveTool(tool) {
  const state = store.getState();
  store.setState({
    ...state,
    toolState: {
      ...state.toolState,
      activeTool: tool,
    },
  });

  document.querySelectorAll("[data-tool]").forEach((button) => {
    button.classList.toggle("active", button.dataset.tool === tool);
  });
  updateCanvasCursor(tool);
  syncColorInputs();
}

function handleSelectPointerDown(event, hit, world) {
  const state = store.getState();
  if (hit) {
    const targetSelectableId = getTopSelectableId(state, hit.id);
    const alreadySelected = state.selection.selectedIds.includes(targetSelectableId);
    let nextIds;

    if (event.shiftKey) {
      const ids = new Set(state.selection.selectedIds);
      ids.add(targetSelectableId);
      nextIds = [...ids];
    } else if (alreadySelected) {
      // Important for beginners: after selecting many items, dragging any one
      // selected item should move the whole selected set together.
      nextIds = state.selection.selectedIds;
    } else {
      nextIds = [targetSelectableId];
    }

    store.setState({
      ...state,
      selection: {
        ...state.selection,
        selectedIds: nextIds,
      },
    });

    interaction.dragMode = "move";
    interaction.moveSnapshot = getSelectionObjects(store.getState()).map((obj) => deepClone(obj));
  } else {
    store.setState({
      ...state,
      selection: {
        ...state.selection,
        selectedIds: event.shiftKey ? state.selection.selectedIds : [],
        marquee: { active: true, x: world.x, y: world.y, width: 0, height: 0 },
      },
    });
    interaction.dragMode = "marquee";
  }
}

function handleCreatePointerDown(tool, world) {
  const state = store.getState();
  interaction.dragMode = "create";

  switch (tool) {
    case TOOLS.RECT:
      interaction.activeDraftObject = createRect(state, world.x, world.y, 0, 0);
      break;
    case TOOLS.ELLIPSE:
      interaction.activeDraftObject = createEllipse(state, world.x, world.y, 0, 0);
      break;
    case TOOLS.DIAMOND:
      interaction.activeDraftObject = createDiamond(state, world.x, world.y, 0, 0);
      break;
    case TOOLS.LINE:
      interaction.activeDraftObject = createLine(state, world.x, world.y, world.x, world.y);
      break;
    case TOOLS.ARROW:
      interaction.activeDraftObject = createArrow(state, world.x, world.y, world.x, world.y);
      break;
    case TOOLS.TEXT: {
      const text = prompt("Type the text you want to place on the board:", "New idea");
      if (text) {
        commandManager.execute({
          type: COMMANDS.ADD_OBJECTS,
          payload: { objects: [createText(state, world.x, world.y, text)] },
        });
      }
      interaction.dragMode = null;
      break;
    }
  }
}

function updateDraftObject(world) {
  const obj = interaction.activeDraftObject;
  if (!obj) return;

  if (obj.type === "line" || obj.type === "arrow") {
    obj.x2 = world.x;
    obj.y2 = world.y;
    return;
  }

  const rect = normalizeRect(interaction.startWorld.x, interaction.startWorld.y, world.x, world.y);
  obj.x = rect.x;
  obj.y = rect.y;
  obj.width = rect.width;
  obj.height = rect.height;
}

function finalizeDraftObject() {
  const obj = interaction.activeDraftObject;
  if (!obj) return;

  const bounds = getObjectBounds(obj);
  const valid =
    (obj.type === "line" || obj.type === "arrow")
      ? Math.hypot(obj.x2 - obj.x1, obj.y2 - obj.y1) > 2
      : bounds.width > 4 && bounds.height > 4;

  if (!valid) return;

  commandManager.execute({
    type: COMMANDS.ADD_OBJECTS,
    payload: { objects: [obj] },
  });
}

function updateMarquee(startWorld, currentWorld) {
  const rect = normalizeRect(startWorld.x, startWorld.y, currentWorld.x, currentWorld.y);
  const state = store.getState();
  store.setState({
    ...state,
    selection: {
      ...state.selection,
      marquee: { active: true, ...rect },
    },
  });
}

function finalizeMarqueeSelection() {
  const state = store.getState();
  const marquee = state.selection.marquee;
  const selectedIds = [];

  for (const obj of state.objects) {
    const bounds = getObjectBounds(obj);
    if (bounds && marqueeIntersect(marquee, bounds)) {
      selectedIds.push(getTopSelectableId(state, obj.id));
    }
  }

  store.setState({
    ...state,
    selection: {
      ...state.selection,
      selectedIds: [...new Set(selectedIds)],
      marquee: { active: false, x: 0, y: 0, width: 0, height: 0 },
    },
  });
}

function updateSelectionMove(world) {
  if (!interaction.moveSnapshot) return;
  const dx = world.x - interaction.startWorld.x;
  const dy = world.y - interaction.startWorld.y;
  const state = store.getState();
  const snapshotMap = new Map(interaction.moveSnapshot.map((obj) => [obj.id, obj]));

  const nextObjects = state.objects.map((obj) => {
    if (!getSelectionObjects(state).some((selected) => selected.id === obj.id)) return obj;

    const original = snapshotMap.get(obj.id);
    if (!original) return obj;

    if (obj.type === "line" || obj.type === "arrow") {
      return {
        ...obj,
        x1: original.x1 + dx,
        y1: original.y1 + dy,
        x2: original.x2 + dx,
        y2: original.y2 + dy,
      };
    }

    return {
      ...obj,
      x: original.x + dx,
      y: original.y + dy,
    };
  });

  store.setState({
    ...state,
    objects: nextObjects,
  });
}

function canTraceMovement(obj) {
  return obj && typeof obj.x === "number" && typeof obj.y === "number" && typeof obj.width === "number" && typeof obj.height === "number";
}

function getObjectCenter(obj) {
  return {
    x: obj.x + obj.width / 2,
    y: obj.y + obj.height / 2,
  };
}

function createMovementTraceArrows(before, after) {
  const state = store.getState();
  const beforeMap = new Map(before.map((obj) => [obj.id, obj]));
  const arrows = [];
  let tempState = { ...state, objects: [...state.objects] };

  for (const moved of after) {
    const original = beforeMap.get(moved.id);
    if (!canTraceMovement(original) || !canTraceMovement(moved)) continue;

    const start = getObjectCenter(original);
    const end = getObjectCenter(moved);
    const distance = Math.hypot(end.x - start.x, end.y - start.y);
    if (distance < 6) continue;

    const arrow = createArrow(tempState, start.x, start.y, end.x, end.y);
    arrow.meta = { ...(arrow.meta || {}), movementTrace: true };
    arrow.style = {
      ...arrow.style,
      stroke: "#2563eb",
      strokeWidth: 3,
      opacity: 0.72,
    };
    arrows.push(arrow);
    tempState.objects.push(arrow);
  }

  return arrows;
}

function finalizeMove() {
  if (!interaction.moveSnapshot) return;
  const state = store.getState();
  const before = interaction.moveSnapshot;
  const after = getSelectionObjects(state).map((obj) => deepClone(obj));
  const traceArrows = movementTrace.enabled ? createMovementTraceArrows(before, after) : [];

  commandManager.execute({
    type: COMMANDS.UPDATE_OBJECTS,
    payload: { before, after },
  });

  if (traceArrows.length) {
    commandManager.execute({
      type: COMMANDS.ADD_OBJECTS,
      payload: { objects: traceArrows },
    });
  }
}


canvas.addEventListener("dblclick", (event) => {
  const screen = getPointerScreenPosition(event);
  const world = renderer.screenToWorld(screen.x, screen.y);
  const state = store.getState();
  const hit = hitTest(state, world.x, world.y);
  if (!hit) return;
  editObjectText(hit);
});

canvas.addEventListener("pointerdown", (event) => {
  closeInlineTextEditor({ commit: true });
  canvas.setPointerCapture(event.pointerId);

  const screen = getPointerScreenPosition(event);
  const world = renderer.screenToWorld(screen.x, screen.y);
  const state = store.getState();
  const tool = state.toolState.activeTool;
  const hit = hitTest(state, world.x, world.y);

  interaction.pointerDown = true;
  interaction.startScreen = screen;
  interaction.startWorld = world;
  interaction.activeDraftObject = null;
  interaction.moveSnapshot = null;

  if (tool === TOOLS.ERASER) {
    interaction.dragMode = "erase";
    interaction.eraseIds = new Set();
    addEraseHit(world);
    return;
  }

  if (tool === TOOLS.SELECT) {
    handleSelectPointerDown(event, hit, world);
    return;
  }

  handleCreatePointerDown(tool, world);
});

canvas.addEventListener("pointermove", (event) => {
  if (!interaction.pointerDown) return;
  const screen = getPointerScreenPosition(event);
  const world = renderer.screenToWorld(screen.x, screen.y);

  if (interaction.dragMode === "create") {
    updateDraftObject(world);
    renderer.setDraftObject(interaction.activeDraftObject);
  } else if (interaction.dragMode === "marquee") {
    updateMarquee(interaction.startWorld, world);
  } else if (interaction.dragMode === "move") {
    updateSelectionMove(world);
  } else if (interaction.dragMode === "erase") {
    addEraseHit(world);
  }
});

canvas.addEventListener("pointerup", () => {
  if (!interaction.pointerDown) return;

  if (interaction.dragMode === "create" && interaction.activeDraftObject) {
    finalizeDraftObject();
  } else if (interaction.dragMode === "marquee") {
    finalizeMarqueeSelection();
  } else if (interaction.dragMode === "move") {
    finalizeMove();
  } else if (interaction.dragMode === "erase") {
    finalizeErase();
  }

  interaction.pointerDown = false;
  interaction.dragMode = null;
  interaction.activeDraftObject = null;
  renderer.setDraftObject(null);
  interaction.moveSnapshot = null;
  interaction.eraseIds = new Set();
  renderer.requestRender();
});

document.querySelectorAll("[data-tool]").forEach((button) => {
  button.addEventListener("click", () => setActiveTool(button.dataset.tool));
});

document.getElementById("groupBtn")?.addEventListener("click", () => {
  const state = store.getState();
  const childIds = getSelectionObjects(state).map((obj) => obj.id);
  if (childIds.length < 2) return;
  const group = createGroup(childIds);
  commandManager.execute({
    type: COMMANDS.GROUP_OBJECTS,
    payload: { group },
  });
});

document.getElementById("ungroupBtn")?.addEventListener("click", () => {
  const state = store.getState();
  const selectedGroupId = state.selection.selectedIds.find((id) => state.groups.some((g) => g.id === id));
  if (!selectedGroupId) return;

  const backup = state.groups.find((g) => g.id === selectedGroupId);
  commandManager.execute({
    type: COMMANDS.UNGROUP_OBJECTS,
    payload: {
      groupId: selectedGroupId,
      groupBackup: deepClone(backup),
    },
  });
});

document.getElementById("undoBtn")?.addEventListener("click", () => commandManager.undo());
document.getElementById("redoBtn")?.addEventListener("click", () => commandManager.redo());

document.getElementById("selectAllBtn")?.addEventListener("click", () => {
  const state = store.getState();
  const ids = state.objects.map((obj) => obj.groupId || obj.id);
  store.setState({
    ...state,
    selection: {
      ...state.selection,
      selectedIds: [...new Set(ids)],
    },
  });
});

document.getElementById("newBtn")?.addEventListener("click", () => {
  const previousState = deepClone(store.getState());
  commandManager.execute({
    type: COMMANDS.CLEAR_BOARD,
    payload: { previousState },
  });
});

document.getElementById("saveBtn")?.addEventListener("click", () => {
  const blob = new Blob([JSON.stringify(store.getState(), null, 2)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "pp-whiteboard.json";
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
});

document.getElementById("loadBtn")?.addEventListener("click", () => {
  document.getElementById("fileInput")?.click();
});

document.getElementById("fileInput")?.addEventListener("change", (event) => {
  const file = event.target.files?.[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = () => {
    try {
      const previousState = deepClone(store.getState());
      const parsed = JSON.parse(String(reader.result));
      const safeState = validateAndNormalizeBoardState(parsed);
      commandManager.execute({
        type: COMMANDS.LOAD_BOARD,
        payload: {
          state: safeState,
          previousState,
        },
      });
    } catch (error) {
      alert("Invalid JSON file.");
      console.error(error);
    }
  };
  reader.readAsText(file);
  event.target.value = "";
});

document.getElementById("pngBtn")?.addEventListener("click", () => {
  const link = document.createElement("a");
  link.download = "pp-whiteboard.png";
  link.href = canvas.toDataURL("image/png");
  link.click();
});

if (strokeColorInput) {
  strokeColorInput.addEventListener("input", (event) => {
    const state = store.getState();
    store.setState({
      ...state,
      toolState: {
        ...state.toolState,
        toolOptions: {
          ...state.toolState.toolOptions,
          stroke: event.target.value,
        },
      },
    });
  });
}

if (fillColorInput) {
  fillColorInput.addEventListener("input", (event) => {
    const state = store.getState();
    store.setState({
      ...state,
      toolState: {
        ...state.toolState,
        toolOptions: {
          ...state.toolState.toolOptions,
          fill: event.target.value,
        },
      },
    });
  });
}

if (strokeWidthInput) {
  strokeWidthInput.addEventListener("input", (event) => {
    const value = Number(event.target.value);
    const state = store.getState();
    store.setState({
      ...state,
      toolState: {
        ...state.toolState,
        toolOptions: {
          ...state.toolState.toolOptions,
          strokeWidth: value,
        },
      },
    });
    if (strokeWidthValue) strokeWidthValue.textContent = String(value);
  });
}

if (fontFamilyInput) {
  fontFamilyInput.addEventListener("change", (event) => {
    const state = store.getState();
    store.setState({
      ...state,
      toolState: {
        ...state.toolState,
        toolOptions: {
          ...state.toolState.toolOptions,
          fontFamily: event.target.value,
        },
      },
    });
  });
}

if (fontSizeInput) {
  fontSizeInput.addEventListener("input", (event) => {
    const value = Number(event.target.value);
    const state = store.getState();
    store.setState({
      ...state,
      toolState: {
        ...state.toolState,
        toolOptions: {
          ...state.toolState.toolOptions,
          fontSize: value,
        },
      },
    });
    if (fontSizeValue) fontSizeValue.textContent = String(value);
  });
}

if (propStroke) {
  propStroke.addEventListener("input", (event) => {
    const color = event.target.value;
    updateSelectedObjects((obj) => {
      obj.style = obj.style || {};
      if (obj.type === "text") obj.style.color = color;
      else obj.style.stroke = color;
    });
  });
}

if (propFill) {
  propFill.addEventListener("input", (event) => {
    const color = event.target.value;
    updateSelectedObjects((obj) => {
      obj.style = obj.style || {};
      if (obj.type !== "line" && obj.type !== "arrow" && obj.type !== "text") {
        obj.style.fill = color;
      }
    });
  });
}

if (propStrokeWidth) {
  propStrokeWidth.addEventListener("input", (event) => {
    const value = Number(event.target.value);
    updateSelectedObjects((obj) => {
      obj.style = obj.style || {};
      obj.style.strokeWidth = value;
    });
  });
}

if (propWidth) {
  propWidth.addEventListener("change", (event) => {
    const value = Number(event.target.value);
    if (!Number.isFinite(value) || value <= 0) return;
    updateSelectedObjects((obj) => {
      if ("width" in obj) obj.width = value;
    });
  });
}

if (propHeight) {
  propHeight.addEventListener("change", (event) => {
    const value = Number(event.target.value);
    if (!Number.isFinite(value) || value <= 0) return;
    updateSelectedObjects((obj) => {
      if ("height" in obj) obj.height = value;
    });
  });
}

if (propFontFamily) {
  propFontFamily.addEventListener("change", (event) => {
    const value = event.target.value;
    updateSelectedObjects((obj) => {
      obj.style = obj.style || {};
      obj.style.fontFamily = value;
    });
  });
}

if (propFontSize) {
  propFontSize.addEventListener("input", (event) => {
    const value = Number(event.target.value);
    updateSelectedObjects((obj) => {
      obj.style = obj.style || {};
      obj.style.fontSize = value;
    });
  });
}

if (propText) {
  propText.addEventListener("input", (event) => {
    const value = event.target.value;
    updateSelectedObjects((obj) => {
      if ("text" in obj) obj.text = value;
    });
  });
}


if (shareHashBtn) {
  shareHashBtn.addEventListener("click", async () => {
    try {
      const url = buildHashShareUrl();
      await copyTextToClipboard(url);
      alert("Share link copied. You can paste it in WhatsApp, email, or your lesson page.");
    } catch (error) {
      console.error(error);
      alert("Could not copy hash share link.");
    }
  });
}

if (shareQueryBtn) {
  shareQueryBtn.addEventListener("click", async () => {
    try {
      const url = buildQueryShareUrl();
      await copyTextToClipboard(url);
      alert("Example JSON link copied. Replace example.json with your file name after uploading.");
    } catch (error) {
      console.error(error);
      alert("Could not copy query share link.");
    }
  });
}

document.getElementById("themeBtn")?.addEventListener("click", () => {
  const root = document.documentElement;
  const next = root.getAttribute("data-theme") === "dark" ? "light" : "dark";
  root.setAttribute("data-theme", next);

  const state = store.getState();
  store.setState({
    ...state,
    settings: {
      ...state.settings,
      theme: next,
    },
  });

  localStorage.setItem("pp-theme", next);
  const themeBtn = document.getElementById("themeBtn");
  if (themeBtn) themeBtn.textContent = next === "dark" ? "Light Mode" : "Dark Mode";
});



if (quickBoxBtn) {
  quickBoxBtn.addEventListener("click", () => makeQuickBoxes());
}

if (quickBoxClearBtn) {
  quickBoxClearBtn.addEventListener("click", () => makeQuickBoxes({ clearFirst: true }));
}

if (quickBoxInput) {
  quickBoxInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      makeQuickBoxes();
    }
  });
}

if (quickBannerBtn) {
  quickBannerBtn.addEventListener("click", () => makeQuickBanners());
}

if (quickBannerClearBtn) {
  quickBannerClearBtn.addEventListener("click", () => makeQuickBanners({ clearFirst: true }));
}

if (quickBannerInput) {
  quickBannerInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      makeQuickBanners();
    }
  });
}
if (editSelectedTextBtn) {
  editSelectedTextBtn.addEventListener("click", updateSelectedTextFromEditor);
}

if (editTextInput) {
  editTextInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      updateSelectedTextFromEditor();
    }
  });
}


if (helpToggle && helpPanel) {
  helpToggle.addEventListener("click", () => {
    const willShow = helpPanel.hidden;
    helpPanel.hidden = !willShow;
    helpToggle.textContent = willShow ? "Hide Guide" : "Show Guide";
  });
}

function syncMovementTraceButton() {
  if (!movementTraceBtn) return;
  movementTraceBtn.textContent = movementTrace.enabled ? "Movement Lines: On" : "Movement Lines: Off";
  movementTraceBtn.classList.toggle("active-toggle", movementTrace.enabled);
  movementTraceBtn.setAttribute("aria-pressed", String(movementTrace.enabled));
}

if (movementTraceBtn) {
  movementTraceBtn.addEventListener("click", () => {
    movementTrace.enabled = !movementTrace.enabled;
    syncMovementTraceButton();
    setActiveTool(TOOLS.SELECT);
  });
  syncMovementTraceButton();
}

document.addEventListener("keydown", (event) => {
  const mod = event.ctrlKey || event.metaKey;
  const state = store.getState();

  if (mod && event.key.toLowerCase() === "z") {
    event.preventDefault();
    commandManager.undo();
  }

  if (mod && event.key.toLowerCase() === "y") {
    event.preventDefault();
    commandManager.redo();
  }

  if (mod && event.key.toLowerCase() === "a") {
    event.preventDefault();
    const ids = state.objects.map((obj) => obj.groupId || obj.id);
    store.setState({
      ...state,
      selection: {
        ...state.selection,
        selectedIds: [...new Set(ids)],
      },
    });
  }

  if (event.key === "Delete" || event.key === "Backspace") {
    if (!state.selection.selectedIds.length) return;
    const ids = getSelectionObjects(state).map((obj) => obj.id);
    const idSet = new Set(ids);
    const deletedObjects = ids.map((id) => getObjectById(state, id)).filter(Boolean).map(deepClone);
    const affectedGroups = state.groups
      .filter((group) => group.childIds.some((childId) => idSet.has(childId)) || state.selection.selectedIds.includes(group.id))
      .map(deepClone);

    commandManager.execute({
      type: COMMANDS.DELETE_OBJECTS,
      payload: {
        ids,
        objectsBackup: deletedObjects,
        groupsBackup: affectedGroups,
      },
    });
  }
});


function encodeStateToHash(state) {
  const json = JSON.stringify(state);
  return btoa(unescape(encodeURIComponent(json)));
}

function decodeHashToState(encoded) {
  const json = decodeURIComponent(escape(atob(encoded)));
  return JSON.parse(json);
}


function validateAndNormalizeBoardState(data) {
  // Beginners may load old or hand-edited JSON files. This keeps the app alive
  // by merging the loaded data with a fresh default board.
  if (!data || typeof data !== "object") {
    throw new Error("The JSON file does not contain a board object.");
  }

  const base = createInitialBoardState();
  const safe = {
    ...base,
    ...data,
    metadata: { ...base.metadata, ...(data.metadata || {}) },
    camera: { ...base.camera, ...(data.camera || {}) },
    settings: { ...base.settings, ...(data.settings || {}) },
    toolState: {
      ...base.toolState,
      ...(data.toolState || {}),
      toolOptions: {
        ...base.toolState.toolOptions,
        ...(data.toolState?.toolOptions || {}),
      },
    },
    selection: {
      ...base.selection,
      ...(data.selection || {}),
      selectedIds: Array.isArray(data.selection?.selectedIds) ? data.selection.selectedIds : [],
      marquee: { ...base.selection.marquee, ...(data.selection?.marquee || {}) },
    },
    objects: Array.isArray(data.objects) ? data.objects.filter((obj) => obj && obj.id && obj.type) : [],
    groups: Array.isArray(data.groups) ? data.groups.filter((group) => group && group.id && Array.isArray(group.childIds)) : [],
    connectors: Array.isArray(data.connectors) ? data.connectors : [],
  };

  return safe;
}

function isSafeJsonPath(file) {
  // Keep ?json= simple for new users: allow relative JSON files only.
  return file.endsWith(".json") && !file.includes("://") && !file.startsWith("//");
}
async function loadJsonFromQuery() {
  const params = new URLSearchParams(window.location.search);
  const file = params.get("json");
  if (!file) return false;

  if (!isSafeJsonPath(file)) {
    alert("For safety, use a local JSON file such as example.json.");
    return false;
  }

  try {
    const response = await fetch(file, { cache: "no-store" });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    const previousState = deepClone(store.getState());
    const safeState = validateAndNormalizeBoardState(data);

    commandManager.execute({
      type: COMMANDS.LOAD_BOARD,
      payload: {
        state: safeState,
        previousState,
      },
    });
    return true;
  } catch (error) {
    console.error("Failed to load JSON from query parameter:", error);
    alert(`Could not load JSON file: ${file}`);
    return false;
  }
}

function loadJsonFromHash() {
  const rawHash = window.location.hash ? window.location.hash.slice(1) : "";
  if (!rawHash) return false;

  try {
    const state = validateAndNormalizeBoardState(decodeHashToState(rawHash));
    const previousState = deepClone(store.getState());

    commandManager.execute({
      type: COMMANDS.LOAD_BOARD,
      payload: {
        state,
        previousState,
      },
    });
    return true;
  } catch (error) {
    console.error("Failed to load board from hash:", error);
    return false;
  }
}

async function copyTextToClipboard(text) {
  await navigator.clipboard.writeText(text);
}

function buildQueryShareUrl() {
  const current = new URL(window.location.href);
  current.hash = "";
  const params = new URLSearchParams(current.search);
  const existing = params.get("json");
  params.set("json", existing || "example.json");
  current.search = params.toString();
  return current.toString();
}

function buildHashShareUrl() {
  const current = new URL(window.location.href);
  current.search = "";
  current.hash = encodeStateToHash(store.getState());
  return current.toString();
}

async function boot() {
  const savedTheme = localStorage.getItem("pp-theme");
  if (savedTheme) {
    document.documentElement.setAttribute("data-theme", savedTheme);
    const themeBtn = document.getElementById("themeBtn");
    if (themeBtn) themeBtn.textContent = savedTheme === "dark" ? "Light Mode" : "Dark Mode";
    const state = store.getState();
    store.setState({
      ...state,
      settings: {
        ...state.settings,
        theme: savedTheme,
      },
    });
  }

  window.addEventListener("resize", () => {
    closeInlineTextEditor({ commit: true });
    renderer.resize();
  });
  renderer.resize();

  syncColorInputs();
  setActiveTool(TOOLS.SELECT);
  syncPropertyPanel();

  const loadedFromQuery = await loadJsonFromQuery();
  if (!loadedFromQuery) {
    loadJsonFromHash();
  }

  renderer.requestRender();
}

boot();

const fullscreenBtn = document.getElementById("fullscreenBtn");

function toggleFullscreen() {
  if (!document.fullscreenElement) {
    document.documentElement.requestFullscreen();
    if (fullscreenBtn) fullscreenBtn.textContent = "Exit Fullscreen";
  } else {
    document.exitFullscreen();
    if (fullscreenBtn) fullscreenBtn.textContent = "Fullscreen";
  }
}

if (fullscreenBtn) {
  fullscreenBtn.addEventListener("click", toggleFullscreen);
}

document.addEventListener("fullscreenchange", () => {
  if (!document.fullscreenElement) {
    if (fullscreenBtn) fullscreenBtn.textContent = "Fullscreen";
  }
});
